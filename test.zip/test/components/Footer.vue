<!--
 * @Author: your name
 * @Date: 2021-08-28 12:34:25
 * @LastEditTime: 2021-09-09 14:34:14
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /tomexam/components/Footer.vue
-->
<template>
  <section class="footer">
    Copyright © 2021 湖南三文在线教育科技集团有限公司 版权所有 All rights reserved
    备案号：湘ICP备19015249号-3
  </section>
</template>
<style>
.footer {
  background: #303030;
  height: 80px;
  line-height: 80px;
  font-size: 14px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  text-align: center;
  color: #ffffff;
  margin-top: 50px;
}
</style>
